import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { ApiService } from './api.service';

import { AppComponent } from './app.component';
import { AppListComponent } from './app-list/app-list.component';
import { HomeComponent } from './home/home.component';
import { GameComponent } from './game/game.component';
import { ThemeComponent } from './theme/theme.component';
import { StickerComponent } from './sticker/sticker.component';
import { SuperHotGamesComponent } from './super-hot-games/super-hot-games.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    GameComponent,
    ThemeComponent,
    StickerComponent,
    SuperHotGamesComponent,
    PageNotFoundComponent,
    AppListComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot([
      { path: '', redirectTo: '/home', pathMatch: 'full' }, 
      { path: 'home', component: HomeComponent}, 
      { path: 'app-list', component: AppListComponent}, 
      { path: 'game', component: GameComponent},
      { path: 'theme', component: ThemeComponent},
      { path: 'sticker', component: StickerComponent},
      { path: '**', component: PageNotFoundComponent }
    ])
  ],
  providers: [ApiService],
  bootstrap: [AppComponent]
})
export class AppModule { }
