import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import 'rxjs/Rx';
import { Observable } from 'rxjs/Observable';

//Service to get data from json file
@Injectable()
export class ApiService {
	url: string = "../../assets/data.json";

	constructor(private http: HttpClient) { 
		
	}

	//get data from the json file
	get() {
		return this.http.get(this.url);
	}
}