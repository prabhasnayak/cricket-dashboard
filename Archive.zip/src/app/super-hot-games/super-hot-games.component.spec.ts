import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SuperHotGamesComponent } from './super-hot-games.component';

describe('SuperHotGamesComponent', () => {
  let component: SuperHotGamesComponent;
  let fixture: ComponentFixture<SuperHotGamesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SuperHotGamesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SuperHotGamesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
