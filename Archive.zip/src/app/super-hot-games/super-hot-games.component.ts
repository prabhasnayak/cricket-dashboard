import { Component, OnInit } from '@angular/core';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-super-hot-games',
  templateUrl: './super-hot-games.component.html',
  styleUrls: ['./super-hot-games.component.css']
})
export class SuperHotGamesComponent implements OnInit {

  data: any;

  constructor(private apiService: ApiService) { }

  ngOnInit() {
  	this.getData();
  }

  getData() {
  	let seq = this.apiService.get().share();

		seq
			.subscribe(res => {
				this.data = res["data"];
			}, err => {
				console.log('in the API error ');
			});
  }

}
